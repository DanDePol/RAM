package com.ram.speed.booster.utils;


public interface Constants {
    public final String TAG="RAMBooster";
    public final String ACTION_SCAN="action.scan";
    public final String ACTION_CLEAN="action.clean";
    public final long weight=1048576;

}
